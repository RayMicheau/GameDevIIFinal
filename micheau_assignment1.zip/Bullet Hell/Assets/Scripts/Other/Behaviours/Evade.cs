﻿using UnityEngine;
using System.Collections;

public class Evade : Flee { }
